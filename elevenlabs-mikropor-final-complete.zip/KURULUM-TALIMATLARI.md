# ElevenLabs Mikropor AI Asistan - Final Paket

## Kurulum:
1. unzip elevenlabs-mikropor-final.zip
2. cd elevenlabs-mikropor-final
3. npm install
4. npm start
5. http://localhost:3000
