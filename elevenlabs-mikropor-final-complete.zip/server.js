const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const axios = require('axios');
const https = require('https');
require('dotenv').config();

const app = express();
// cPanel için port ayarı
const PORT = process.env.PORT || process.env.CPANEL_PORT || 3000;

// Axios global konfigürasyonu
axios.defaults.timeout = 30000;
axios.defaults.httpsAgent = new https.Agent({
    keepAlive: true,
    keepAliveMsecs: 1000,
    maxSockets: 50,
    maxFreeSockets: 10,
    timeout: 60000,
    freeSocketTimeout: 30000,
    secureProtocol: 'TLSv1_2_method'
});

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(express.static('.'));

// Ana sayfa
app.get('/', (req, res) => {
    res.sendFile(__dirname + '/index.html');
});

// Retry fonksiyonu
async function retryApiCall(apiCall, maxRetries = 3, delay = 1000) {
    for (let i = 0; i < maxRetries; i++) {
        try {
            return await apiCall();
        } catch (error) {
            console.log(`API çağrısı ${i + 1}. deneme başarısız:`, error.message);
            
            if (i === maxRetries - 1) {
                throw error; // Son deneme, hatayı fırlat
            }
            
            // Exponential backoff
            await new Promise(resolve => setTimeout(resolve, delay * Math.pow(2, i)));
        }
    }
}

// Arama API endpoint'i - Gerçek Batch Calling
app.post('/api/call', async (req, res) => {
    try {
        const { phoneNumber } = req.body;
        
        // Telefon numarası validasyonu
        if (!phoneNumber || !phoneNumber.match(/^\+90[0-9]{10}$/)) {
            return res.status(400).json({
                error: 'Geçersiz telefon numarası formatı. +905XXXXXXXXX formatında olmalıdır.'
            });
        }

        console.log(`Arama isteği alındı: ${phoneNumber}`);

        try {
            // Önce mevcut telefon numaralarını al - retry ile
            const phoneNumbersResponse = await retryApiCall(async () => {
                return await axios.get(
                    'https://api.elevenlabs.io/v1/convai/phone-numbers',
                    {
                        headers: {
                            'xi-api-key': process.env.ELEVENLABS_API_KEY
                        },
                        timeout: 10000 // 10 saniye timeout
                    }
                );
            });

            console.log('Telefon numaraları yanıtı:', phoneNumbersResponse.data);

            if (!phoneNumbersResponse.data || phoneNumbersResponse.data.length === 0) {
                return res.status(200).json({
                    success: false,
                    message: 'Demo Modu: Telefon numarası henüz entegre edilmemiş',
                    phoneNumber: phoneNumber,
                    demoMode: true,
                    instructions: [
                        '🔧 Gerçek arama için şu adımları takip edin:',
                        '1. Elevenlabs hesabınıza gidin: https://elevenlabs.io',
                        '2. Conversational AI > Phone Numbers bölümüne gidin',
                        '3. "Add Phone Number" butonuna tıklayın',
                        '4. Twilio seçeneğini seçin',
                        '5. Telefon numaranız: +18609435227',
                        '6. Twilio Account SID ve Auth Token bilgilerinizi girin',
                        '7. Bu sayfayı yenileyin ve tekrar deneyin'
                    ]
                });
            }

            // İlk telefon numarasını kullan veya belirli ID'yi ara
            let selectedPhoneNumber = phoneNumbersResponse.data[0];
            
            // Eğer belirli bir telefon numarası ID'si varsa onu kullan
            const targetPhoneNumberId = 'phnum_01jwsc1q05eq7r8yx9nvk3jc02';
            const foundPhoneNumber = phoneNumbersResponse.data.find(phone => 
                phone.phone_number_id === targetPhoneNumberId
            );
            
            if (foundPhoneNumber) {
                selectedPhoneNumber = foundPhoneNumber;
                console.log('Hedef telefon numarası bulundu:', selectedPhoneNumber);
            } else {
                console.log('Hedef telefon numarası bulunamadı, ilk numarayı kullanıyorum:', selectedPhoneNumber);
            }

            // Elevenlabs Batch Calling API çağrısı - retry ile
            const elevenlabsResponse = await retryApiCall(async () => {
                return await axios.post(
                    `https://api.elevenlabs.io/v1/convai/batch-calling/submit`,
                    {
                        call_name: "E-ticaret AI Asistan Araması",
                        agent_id: process.env.ELEVENLABS_AGENT_ID,
                        agent_phone_number_id: selectedPhoneNumber.phone_number_id,
                        recipients: [
                            {
                                phone_number: phoneNumber
                            }
                        ],
                        scheduled_time_unix: Math.floor(Date.now() / 1000) + 5 // 5 saniye sonra ara
                    },
                    {
                        headers: {
                            'xi-api-key': process.env.ELEVENLABS_API_KEY,
                            'Content-Type': 'application/json'
                        },
                        timeout: 15000 // 15 saniye timeout
                    }
                );
            });

            console.log('Elevenlabs yanıtı:', elevenlabsResponse.data);

            res.json({
                success: true,
                message: 'Arama başarıyla başlatıldı! AI asistanımız sizi 5 saniye içinde arayacak.',
                batchId: elevenlabsResponse.data.id,
                phoneNumber: phoneNumber,
                scheduledTime: elevenlabsResponse.data.scheduled_time_unix,
                callerNumber: selectedPhoneNumber.phone_number,
                phoneNumberId: selectedPhoneNumber.phone_number_id
            });

        } catch (apiError) {
            console.error('API Hatası:', apiError.message);
            console.error('API Hata Detayları:', apiError.response?.data);
            
            // API hatası durumunda demo modu
            return res.status(200).json({
                success: false,
                message: 'Demo Modu: API bağlantı sorunu',
                phoneNumber: phoneNumber,
                demoMode: true,
                error: apiError.message,
                errorDetails: apiError.response?.data,
                instructions: [
                    '🔧 Gerçek arama için şu adımları takip edin:',
                    '1. Elevenlabs hesabınıza gidin: https://elevenlabs.io',
                    '2. Conversational AI > Phone Numbers bölümüne gidin',
                    '3. "Add Phone Number" butonuna tıklayın',
                    '4. Twilio seçeneğini seçin',
                    '5. Telefon numaranız: +18609435227',
                    '6. Twilio Account SID ve Auth Token bilgilerinizi girin',
                    '7. Bu sayfayı yenileyin ve tekrar deneyin'
                ]
            });
        }

    } catch (error) {
        console.error('Genel arama hatası:', error.message);
        
        res.status(500).json({
            error: 'Arama başlatılırken bir hata oluştu',
            details: process.env.NODE_ENV === 'development' ? error.message : undefined
        });
    }
});

// Arama durumu kontrolü
app.get('/api/call-status/:batchId', async (req, res) => {
    try {
        const { batchId } = req.params;
        
        const response = await axios.get(
            `https://api.elevenlabs.io/v1/convai/batch-calling/batches/${batchId}`,
            {
                headers: {
                    'xi-api-key': process.env.ELEVENLABS_API_KEY
                }
            }
        );

        res.json(response.data);
    } catch (error) {
        console.error('Durum kontrolü hatası:', error.response?.data || error.message);
        res.status(500).json({
            error: 'Arama durumu kontrol edilemedi'
        });
    }
});

// Agent bilgilerini kontrol et
app.get('/api/agent-info', async (req, res) => {
    try {
        const response = await axios.get(
            `https://api.elevenlabs.io/v1/convai/agents/${process.env.ELEVENLABS_AGENT_ID}`,
            {
                headers: {
                    'xi-api-key': process.env.ELEVENLABS_API_KEY
                }
            }
        );
        
        console.log('Agent bilgileri:', response.data);
        res.json(response.data);
    } catch (error) {
        console.error('Agent bilgileri alınamadı:', error.response?.data || error.message);
        res.status(500).json({
            error: 'Agent bilgileri alınamadı',
            details: error.response?.data || error.message
        });
    }
});

// Telefon numaralarını listele
app.get('/api/phone-numbers', async (req, res) => {
    try {
        const response = await retryApiCall(async () => {
            return await axios.get(
                'https://api.elevenlabs.io/v1/convai/phone-numbers',
                {
                    headers: {
                        'xi-api-key': process.env.ELEVENLABS_API_KEY
                    },
                    timeout: 10000 // 10 saniye timeout
                }
            );
        });
        
        console.log('Mevcut telefon numaraları:', response.data);
        res.json({
            phoneNumbers: response.data,
            count: response.data ? response.data.length : 0,
            message: response.data && response.data.length > 0 
                ? 'Telefon numaraları bulundu' 
                : 'Hesabınızda telefon numarası bulunamadı. Lütfen Elevenlabs hesabınızda telefon numarası ekleyin.'
        });
    } catch (error) {
        console.error('Telefon numaraları alınamadı:', error.message);
        res.status(500).json({
            error: 'Telefon numaraları alınamadı',
            details: error.message,
            suggestion: 'Agent bilgilerinden telefon numarası görünüyor, bu geçici bir bağlantı sorunu olabilir.'
        });
    }
});

// Test endpoint - basit API çağrısı
app.get('/api/test-connection', async (req, res) => {
    try {
        console.log('API bağlantısı test ediliyor...');
        
        const response = await axios.get(
            'https://api.elevenlabs.io/v1/user',
            {
                headers: {
                    'xi-api-key': process.env.ELEVENLABS_API_KEY,
                    'Accept': 'application/json',
                    'User-Agent': 'Node.js/Axios'
                },
                timeout: 10000
            }
        );
        
        console.log('API bağlantısı başarılı:', response.status);
        res.json({
            success: true,
            message: 'API bağlantısı başarılı',
            status: response.status,
            subscription: response.data.subscription?.tier || 'unknown'
        });
    } catch (error) {
        console.error('API bağlantı hatası:', error.message);
        console.error('Hata kodu:', error.code);
        console.error('Hata detayları:', error.response?.data);
        
        res.status(500).json({
            error: 'API bağlantı hatası',
            message: error.message,
            code: error.code,
            details: error.response?.data
        });
    }
});

// Health check endpoint
app.get('/health', (req, res) => {
    res.json({
        status: 'OK',
        timestamp: new Date().toISOString(),
        environment: process.env.NODE_ENV || 'development',
        apiKeyConfigured: !!process.env.ELEVENLABS_API_KEY,
        agentIdConfigured: !!process.env.ELEVENLABS_AGENT_ID,
        phoneNumber: "+1 860 943 5227"
    });
});

// 404 handler
app.use('*', (req, res) => {
    res.status(404).json({
        error: 'Endpoint bulunamadı'
    });
});

// Error handler
app.use((error, req, res, next) => {
    console.error('Sunucu hatası:', error);
    res.status(500).json({
        error: 'Sunucu hatası',
        details: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
});

// Server başlatma
app.listen(PORT, () => {
    console.log(`🚀 Server ${PORT} portunda çalışıyor`);
    console.log(`📱 Uygulama: http://localhost:${PORT}`);
    console.log(`🔧 Health check: http://localhost:${PORT}/health`);
    console.log(`📞 Telefon numaraları: http://localhost:${PORT}/api/phone-numbers`);
    console.log(`🤖 Agent bilgileri: http://localhost:${PORT}/api/agent-info`);
    console.log(`📞 Arama telefon numarası: +1 860 943 5227`);
    
    // Çevre değişkenlerini kontrol et
    if (!process.env.ELEVENLABS_API_KEY) {
        console.warn('⚠️  ELEVENLABS_API_KEY çevre değişkeni tanımlanmamış!');
    }
    if (!process.env.ELEVENLABS_AGENT_ID) {
        console.warn('⚠️  ELEVENLABS_AGENT_ID çevre değişkeni tanımlanmamış!');
    }
    
    console.log('\n✅ Kurulum tamamlandı! Artık gerçek aramalar yapabilirsiniz.');
    console.log('🎯 Test etmek için bir telefon numarası girin ve "Hemen Ara" butonuna tıklayın.\n');
});

module.exports = app;
